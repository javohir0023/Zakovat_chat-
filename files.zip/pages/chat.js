import Chat from '../components/Chat';

export default function ChatPage() {
  return (
    <div className="flex flex-col h-screen bg-gray-800">
      <Chat />
    </div>
  );
}